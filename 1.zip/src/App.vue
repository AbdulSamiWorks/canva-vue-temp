<template>
  <section class="app">
    <TopBar
      :has-selection="selectedIds.length > 0"
      :styleState="currentStyle"
      @apply-style="applyPatchToSelection"
      @delete-selected="deleteSelected"
    />

    <div class="body">
      <LeftMenu
        @add-text="addText"
        @add-shape="addShape"
        @add-image="addImage"
        @move-layer="handleMoveLayer"
        @bring-front="handleBringFront"
        @send-back="handleSendBack"
      />

      <CanvasArea
        :elements="elements"
        :selectedIds="selectedIds"
        @update:selectedIds="(ids) => (selectedIds = ids)"
        @update:content="updateContent"
        @update:geometry="updateGeometry"
        @delete="deleteSelected"
      />

      <LayersPanel
        :elements="elements"
        :selectedIds="selectedIds"
        @select="(id) => (selectedIds = [id])"
        @toggle-lock="toggleLock"
        @toggle-visibility="toggleVisibility"
      />
    </div>
  </section>
</template>

<script setup>
import { computed } from "vue";
import TopBar from "./components/layout/TopBar.vue";
import LeftMenu from "./components/layout/LeftMenu.vue";
import CanvasArea from "./components/canvas/CanvasArea.vue";
import LayersPanel from "./components/layers/LayersPanel.vue";

import {
  state as elementsState,
  addTextElement,
  addShapeElement,
  addImageElement,
  applyPatchToSelection,
  deleteByIds,
  updateContentById,
  updateGeometryById,
  moveLayer,
  bringToFront,
  sendToBack,
  toggleLock,
  toggleVisibility,
} from "./modules/elements/elements.store";

const elements = elementsState.items;
const selectedIds = elementsState.selectedIds;

function addText() {
  addTextElement();
}

function addShape(shapeType) {
  addShapeElement(shapeType);
}

function addImage(file) {
  addImageElement(file);
}

function deleteSelected() {
  deleteByIds(selectedIds.value);
}

function applyStyleToSelection(patch) {
  applyPatchToSelection(patch);
}

function updateContent(payload) {
  updateContentById(payload.id, payload.content);
}

function updateGeometry(payload) {
  updateGeometryById(payload.id, payload);
}

function handleMoveLayer(direction) {
  moveLayer(direction);
}

function handleBringFront() {
  bringToFront();
}

function handleSendBack() {
  sendToBack();
}

const currentStyle = computed(() => {
  if (!selectedIds.value.length) return null;
  const el = elements.value.find((e) => e.id === selectedIds.value[0]);
  if (!el) return null;

  return {
    type: el.type,
    fontFamily: el.fontFamily,
    fontSize: el.fontSize,
    color: el.color,
    bold: el.bold,
    italic: el.italic,
    underline: el.underline,
    fill: el.fill,
    stroke: el.stroke,
    strokeWidth: el.strokeWidth,
    borderRadius: el.borderRadius,
    opacity: el.opacity,
  };
});
</script>

<style scoped>
.app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background: #f9fafb;
}

.body {
  display: flex;
  flex: 1;
  overflow: hidden;
}
</style>
