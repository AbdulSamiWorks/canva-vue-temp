import { createApp } from "vue";
import App from "./App.vue";
import "./assets/styles/base.css";
import "./assets/styles/theme.css";

createApp(App).mount("#app");
